from django.apps import AppConfig


class Primavera19Config(AppConfig):
    name = 'primavera19'
