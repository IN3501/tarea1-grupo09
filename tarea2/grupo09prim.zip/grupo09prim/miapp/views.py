from django.shortcuts import render

# Create your views here.
def index(request):
	return render(request, 'home.html')

def ingresar(request):
	return render(request, 'ingresar.html')

def contacto(request):
	return render(request, 'contacto.html')

def registro(request):
	return render(request, 'registro.html')

def solicitar(request):
	return render(request, 'solicitar.html')


def recuperar(request):
	nombre=request.POST["nombre"]
	usuario=request.POST["usuario"]
	correo=request.POST["correo"]
	diccionario={}
	diccionario["comentario"]=nombre
	diccionario["comentario2"]=usuario
	diccionario["comentario3"]=correo
	return render(request, "mostrar_resultado.html", diccionario)

