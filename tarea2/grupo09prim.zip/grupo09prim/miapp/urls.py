from django.urls import path
from .views import * 

urlpatterns = [
	path('', index, name ='index'),
	path('ingresar/', ingresar, name='ingresar'),
	path('contacto/', contacto, name='contacto'),
	path('registro/', registro, name='registro'),
	path('solicitar/', solicitar, name='solicitar'),
	path("mostrar_resultado", recuperar, name='mostrar_resultado'),
	
]